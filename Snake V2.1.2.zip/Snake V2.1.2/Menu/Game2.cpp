#include "stdafx.h"
#include "Game2.h"

using namespace std;

void Game2::printIt(){
	
	getNewCoord();

	CConsole c;
	//��ӡ��ǰ����
	c.SetCoord(89 - 8, 5);
	int score = (coord.size() - 4) * 10;
	cout << score;


	//�жϵ�ǰ�����Ƿ���ڼ�¼�֣�����ˢ��
	int *a = getHistoryScore();
	if (a[1] < score)
	{
		int b[3] = {a[0],score,a[2]};
		setHistoryScore(b);
		c.SetCoord(89 - 8, 2);
		cout << score;
		return;
	}
	c.SetCoord(89 - 8, 2);
	cout << a[1];
}

void Game2::printIt_once()
{
/////////////////��ӡ�ϰ���////////////////////////
	for (int i = 21; i < 24; i++) {
		for (int j = 29; j < 62; j++) {
			if ((i == 21 && j == 29) || (i == 21 && j == 61) || (i == 22 && j == 31) || (i == 22 && j == 59) ||
				(i == 23 && j == 33) || (i == 23 && j == 57) || (i == 21 && j == 30) || (i == 21 && j == 60) ||
				(i == 22 && j == 32) || (i == 22 && j == 58) || (i == 23 && j == 34) || (i == 23 && j == 56)) {
				map[j][i] = 3;
				bcoord.push_back(make_pair(j, i));
				if (j % 2 == 0) {
					CConsole g;
					g.SetCoord(j, i);
					cout << "��";
				}
			}
		}
	}

	for (int i = 0; i < 35; i++) {
		if (i == 6 || i == 8 || i == 10 || i == 12 || i == 14) {
			map[44][i] = 3;
			bcoord.push_back(make_pair(44, i));
			map[45][i] = 3;
			bcoord.push_back(make_pair(45, i));
			CConsole g;
			g.SetCoord(44, i);
			cout << "��";

		}
	}

	for (int i = 35; i < 55; i++) {
		map[i][24] = 3;
		bcoord.push_back(make_pair(i, 24));
		if (i % 2 == 0) {
			CConsole g;
			g.SetCoord(i, 24);
			cout << "��";
		}
	}

	for (int i = 20; i < 30; i++) {
		for (int j = 8; j < 10; j++) {
			map[i][j] = 3;
			bcoord.push_back(make_pair(i, j));
			if (i % 2 == 0) {
				CConsole g;
				g.SetCoord(i, j);
				cout << "��";
			}

		}
	}
	for (int i = 60; i < 70; i++) {
		for (int j = 8; j < 10; j++) {
			map[i][j] = 3;
			bcoord.push_back(make_pair(i, j));
			if (i % 2 == 0) {
				CConsole g;
				g.SetCoord(i, j);
				cout << "��";
			}

		}
	}
/////////////////////////////////
	Model::printIt_once();//��ӡ�ߣ�ʳ��
	//��ӡ��¼����
	CConsole c;
	c.SetCoord(89 - 8, 2);
	int *a = getHistoryScore();
	cout << a[1];
}
