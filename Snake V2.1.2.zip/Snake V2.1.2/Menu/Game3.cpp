#include "stdafx.h"
#include "Game3.h"

using namespace std;

void Game3::printIt() {
	
	getNewCoord();
	//�����ǰ����
	CConsole c;
	c.SetCoord(89 - 8, 5);
	int score = (coord.size() - 4) * 10;
	cout << score;


	//�жϵ�ǰ�����Ƿ���ڼ�¼����������ˢ��
	int *a = getHistoryScore();
	if (a[2] < score)
	{
		int b[3] = { 0,0,score };
		setHistoryScore(b);
		c.SetCoord(89 - 8, 2);
		cout << score;
		return;
	}
	c.SetCoord(89 - 8, 2);
	cout << a[2];
}

void Game3::printIt_once()
{
	//////////////////��ӡ�ϰ���///////////////////////
	for (int i = 0; i < 35; i++) {
		if (i != 11 && i != 12 && i != 24) {
			map[45][i] = 3;
			bcoord.push_back(make_pair(45, i));
			map[44][i] = 3;
			bcoord.push_back(make_pair(44, i));
			CConsole g;
			g.SetCoord(44, i);
			cout << "��";

		}
	}
	for (int i = 18; i < 32; i++) {
		map[i][14] = 3;
		bcoord.push_back(make_pair(i, 14));
		if (i % 2 == 0) {
			CConsole g;
			g.SetCoord(i, 14);
			cout << "��";
		}
		map[i][18] = 3;
		bcoord.push_back(make_pair(i, 18));
		if (i % 2 == 0) {
			CConsole g;
			g.SetCoord(i, 18);
			cout << "��";
		}
	}
	for (int i = 58; i < 72; i++) {
		map[i][14] = 3;
		bcoord.push_back(make_pair(i, 14));
		if (i % 2 == 0) {
			CConsole g;
			g.SetCoord(i, 14);
			cout << "��";
		}
		map[i][18] = 3;
		bcoord.push_back(make_pair(i, 18));
		if (i % 2 == 0) {
			CConsole g;
			g.SetCoord(i, 18);
			cout << "��";
		}
	}
////////////////////////////////////////////////

	Model::printIt_once();//��ӡ�ߣ�ʳ��

	//��ӡ��¼��
	CConsole c;
	c.SetCoord(89 - 8, 2);
	int *a = getHistoryScore();
	cout << a[2];
}

