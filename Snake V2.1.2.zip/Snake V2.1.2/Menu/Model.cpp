#include "stdafx.h"
#include "Model.h"
using namespace std;


void Model::makeModel()
{
	coord = { { 12,12 },{ 14,12 },{ 16,12 },{ 18,12 } };
	map[12][12] = map[14][12] = map[16][12] = map[18][12] = 1;
	gameFlag = gameRun;
	speed = 3;
	dir = 'a';
	foodFlag = false;
}

void Model::move()
{
	double count = clock();//��ʱ
	printIt_once();
	gameFlag = gameRun;
	while (true)
	{
		bool coutB = false;//��ʱˢ�±�־
		coutB = clock() - count > (1 / speed * 1000);

		newFood();
		
		static bool flag = false;
		if (_kbhit() && !flag) {
			int ch = _getch();
			if (ch == 27)
			{
				gameFlag = gamePause;
				break;
			}
			flag = control(ch);
		}
		if (coutB)
		{
			printIt();
			flag = false;
			if (gameFlag == gameOver || gameFlag == gamePause)
			{
				break;
			}
			count = clock();
		}
	}
}

bool Model::control(char c)
{
	switch (c)
	{
	case 'w':
		if (dir == 's') {
			return false;
		}
		break;
	case 'a':
		if (dir == 'd') {
			return false;
		}
		break;
	case 's':
		if (dir == 'w') {
			return false;
		}
		break;
	case 'd':
		if (dir == 'a') {
			return false;
		}
		break;
	default:
		return  false;
	}

	dir = c;
	return true;
}

void Model::printIt_once()
{
	CConsole c;
	for each (pair<int, int> var in coord)
	{
		c.SetCoord(var.first, var.second);
		cout << "��";
	}
	auto y = coord.begin();
	c.SetCoord(y->first, y->second);
	cout << "��";
	if (foodFlag == true)
	{
		c.SetCoord(fcoord.first, fcoord.second);
		cout << "��";
	}
	for (int i = 0; i < 8; i++)
	{
		c.SetCoord(89 - 15 , i);
		cout << "��";
	}
	for (int i = 89 - 15; i < 88;)
	{
		c.SetCoord(i, 7);
		cout << "��";
		i += 2;
	}
	for (int i = 89 - 15; i < 89; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			map[i][j] = 3;
			map[i - 1][j] = 3;
		}
	}
	c.SetCoord(89 - 14 + 4,1);
	cout << "��ʷ���";

	c.SetCoord(89 - 14 + 4, 4);
	cout << "��ǰ����";
	c.SetCoord(89 - 8, 5);
	int score = (coord.size() - 4) * 10;
	cout << score;

}


void Model::setHistoryScore(int * a)
{
	ofstream ofs("data.txt");
	ofs << a[0] << " " << a[1] << " " << a[2] << " ";
}

int * Model::getHistoryScore()
{
	static int a[3] = {0};
	try
	{
		ifstream ifs("data.txt");
		if (!ifs.is_open())
		{
			throw 1;
		}
		ifs >> a[0] >> a[1] >> a[2];
	}
	catch (int a)
	{
		ofstream ofs("data.txt");
		ofs << 0 << " " << 0 << " " << 0 << " ";
	}
	return a;
}

void Model::getNewCoord()
{
	pair<int, int> temp = { 0,0 };
	//���ݷ���������꣬���������ײ���ڵ�game over
	switch (dir)
	{
	case'w':
		temp.first = coord.front().first;
		temp.second = coord.front().second - 1;
		if (map[temp.first][temp.second] == 1 || map[temp.first][temp.second] == 3 || temp.second < 0)//�ж��Ƿ�Ϊgame over 1Ϊ�� 3Ϊ�ϰ���
		{
			gameFlag = gameOver;
			return;
		}
		break;
	case'a':
		temp.first = coord.front().first - 2;
		temp.second = coord.front().second;
		if (map[temp.first][temp.second] == 1 || map[temp.first][temp.second] == 3 || temp.first < 0)//�ж��Ƿ�Ϊgame over 1Ϊ�� 3Ϊ�ϰ���
		{
			gameFlag = gameOver;
			return;
		}
		break;
	case's':
		temp.first = coord.front().first;
		temp.second = coord.front().second + 1;
		if (map[temp.first][temp.second] == 1 || map[temp.first][temp.second] == 3 || temp.second >= 35)//�ж��Ƿ�Ϊgame over 1Ϊ�� 3Ϊ�ϰ���
		{
			gameFlag = gameOver;
			return;
		}
		break;
	case'd':
		temp.first = coord.front().first + 2;
		temp.second = coord.front().second;
		if (map[temp.first][temp.second] == 1 || map[temp.first][temp.second] == 3 || temp.first >= 88)//�ж��Ƿ�Ϊgame over 1Ϊ�� 3Ϊ�ϰ���
		{
			gameFlag = gameOver;
			return;
		}
		break;
	case 27:
		gameFlag = gamePause;
		return;
	default:
		break;
	}
	speed = (coord.size() - 4) / 2 + 3;
	//�ػ�ͷ�ڵ�
	map[temp.first][temp.second] = 1;//��õ���ռ��
	coord.push_front(temp);
	CConsole c;
	c.SetCoord(temp.first, temp.second);
	cout << "��";
	auto p = coord.begin();
	p++;
	c.SetCoord(p->first, p->second);
	cout << "��";

	//����ʳ�ﲻȥ��β�ڵ�
	if (temp == fcoord)
	{
		foodFlag = false;
		return;
	}

	//ȥ��β�ڵ�
	int oldbackx = coord.back().first;
	int oldbacky = coord.back().second;

	map[oldbackx][oldbacky] = false;//��õ㲻��ռ��
	c.SetCoord(oldbackx, oldbacky);
	cout << " ";
	coord.pop_back();
}

void Model::newFood()
{
	srand((unsigned int)time(nullptr));
	if (foodFlag == true)
	{
		return;
	}

	int x;
	int y;
	while (true) {
		y = rand() % 30;
		x = rand() % 60;
		if (x % 2 != 0) {
			continue;
		}
		if (map[x][y] == 0)
		{
			break;
		}
	}
	foodFlag = true;
	fcoord = { x,y };
	map[x][y] = 2;
	CConsole c;
	c.SetCoord(x, y);
	cout << "��";
}
