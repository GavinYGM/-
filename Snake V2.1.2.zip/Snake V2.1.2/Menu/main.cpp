#include "stdafx.h"
#include "View.h"
#include"Control.h"
using namespace std;
int main() {
	Control c;
	c.programStart();
}