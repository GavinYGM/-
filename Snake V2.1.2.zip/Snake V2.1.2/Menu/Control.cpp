#include "stdafx.h"
#include "Control.h"
using namespace std;
int Control::MouseSelect()//��ȡ���ѡ��İ�ť���
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO bInfo;
	INPUT_RECORD    mouseRec;
	DWORD           res;
	COORD           crPos, crhome = { 0, 0 };


	while (true)
	{
		ReadConsoleInput(hIn, &mouseRec, 1, &res);

		if (mouseRec.EventType == MOUSE_EVENT)
		{

			crPos = mouseRec.Event.MouseEvent.dwMousePosition;

			GetConsoleScreenBufferInfo(hOut, &bInfo);
			SetConsoleCursorPosition(hOut, crPos);

			if (mouseRec.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
			{
				if (crPos.X >= 39 && crPos.X <= 48 && crPos.Y >= 15.5 && crPos.Y <= 16.5)
				{
					return 1;
				}
			
				else if (crPos.X >= 39 && crPos.X <= 48 && crPos.Y >= 18 && crPos.Y <= 19.5)
				{
					return 2;
				}
			
				else if (crPos.X >= 39 && crPos.X <= 48 && crPos.Y >= 21 && crPos.Y <= 22.5)
				{
					return 3;
				}
			
				else if (crPos.X >= 39 && crPos.X <= 48 && crPos.Y >= 24 && crPos.Y <= 25.5)
				{
					return 4;
				}
			
				else if (crPos.X >= 39 && crPos.X <= 48 && crPos.Y >= 27 && crPos.Y <= 28.5)
				{
					return 5;
				}
			}
		}
	}
}

void Control::programStart()
{
	vi.setWords("����̰����ԡ����ߡ���");
	while (true)
	{

		static int choice1 = 0;						//�˵�ѡ��
		static int choice2 = 0;						//����ѡ��
		static int choice3 = 0;						//��Ϸѡ��

		if (choice1 == 0)							//��ʼ�˵�
		{
			vi.startMenu();
			choice2 = MouseSelect();				//��ȡ���ѡ��İ�ť���
			while (choice2 == 2)
			{
				choice2 = MouseSelect();
			}
		}
		else if (choice1 == 1)						//��ͣ�˵�
		{
			vi.pasueMenu();
			choice2 = MouseSelect();				//��ȡ���ѡ��İ�ť���
			if (choice2 == 3)
			{
				choice1 = 0;
				continue;
			}
			if (choice2 == 4)
			{
				choice2 = 3;
			}
		}
		else if (choice1 == 2)						//�����˵�
		{
			vi.endMenu();
			choice2 = MouseSelect();				//��ȡ���ѡ��İ�ť���
			while (choice2 == 4)
			{
				choice2 = MouseSelect();
			}
			if (choice2 == 2)
			{
				choice2 = 3;
			}
			else if (choice2 == 3)
			{
				choice1 = 0;
				continue;
			}

		}
		
		if (choice2 == 1)							//�µ���Ϸ
		{
			vi.gameChoice();
			int choice3 = MouseSelect();			//��ȡ���ѡ��İ�ť���
			while (choice3 > 4)
			{
				choice3 = MouseSelect();
			}
			if (choice3 == 4)
			{
				continue;
			}
			delete m;
			m = nullptr;
			cls();
			switch (choice3)
			{
			case 1:
				m = new Game1;
				break;
			case 2:
				m = new Game2;
				break;
			case 3:
				m = new Game3;
				break;
			default:
				break;
			}
			m->makeModel();
			m->move();
			if (m->getGameFlag() == gamePause)
			{
				choice1 = 1;
				continue;
			}
			else
			{
				choice1 = 2;
				delete m;
				m = nullptr;
				continue;
			}
		}
		else if (choice2 == 2)							//������Ϸ
		{
			if (m != nullptr)
			{
				cls();
				m->printIt_once();
				while (true)
				{
					if (_kbhit())
						break;
				}
				m->move();
				if (m->getGameFlag() == gamePause)
				{
					choice1 = 1;
					continue;
				}
				else
				{
					choice1 = 2;
					delete m;
					m = nullptr;
					continue;
				}
			}
			else 
			{
				choice1 = 0;
				continue;
			}
		}
		else if (choice2 == 3)								//����
		{
			vi.help();
			int choice4 = MouseSelect();
			while (choice4 != 4)
			{
				int choice4 = MouseSelect();
			}
			continue;
		}
		else if (choice2 == 4)								//����
		{
			vi.about();
			int choice4 = MouseSelect();
			while (choice4 != 4)
			{
				int choice4 = MouseSelect();
			}
			continue;
		}
		else if (choice2 == 5)								//�˳�
		{
			vi.end();
			exit(0);
		}

	}

	
}
